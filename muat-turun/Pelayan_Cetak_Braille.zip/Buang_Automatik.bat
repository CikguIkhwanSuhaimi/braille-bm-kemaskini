@echo off
title Buang pelayan cetak automatik
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell -NoProfile -Command "Remove-Item ([Environment]::GetFolderPath('CommonStartup')+'\Pelayan Cetak Braille.lnk') -ErrorAction SilentlyContinue"
netsh http delete urlacl url=http://+:8080/ >nul 2>&1
reg delete "HKCR\bprint" /f >nul 2>&1
echo Dibuang. Pelayan tidak lagi jalan sendiri.
pause
