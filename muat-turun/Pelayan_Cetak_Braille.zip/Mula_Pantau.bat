@echo off
title Pantau Embosser
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Pantau_Embosser.ps1"
pause
