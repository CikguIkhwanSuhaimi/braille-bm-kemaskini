@echo off
title Alamat PC untuk pelayan cetak
echo Buka salah satu alamat ini di fon (Wi-Fi yang sama):
echo.
powershell -NoProfile -Command "Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | ForEach-Object { 'http://{0}:8080' -f $_.IPAddress }"
echo.
pause
