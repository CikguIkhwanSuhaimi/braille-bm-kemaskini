' Jalankan pelayan cetak tanpa sebarang tetingkap (berfungsi juga dengan Windows Terminal)
Dim fso, sh, d
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
d = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = d
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & d & "\Pelayan_Cetak.ps1""", 0, False
