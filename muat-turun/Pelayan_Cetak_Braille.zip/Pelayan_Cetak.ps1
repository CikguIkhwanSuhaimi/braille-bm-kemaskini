# Pelayan cetak Braille: hidangkan aplikasi di rangkaian sekolah dan hantar BRF terus ke embosser.
# SMK Pendidikan Khas Setapak. Jalankan melalui Mula_Pelayan.bat (klik dua kali).

# ===== TETAPAN =====
$IP       = "192.168.0.240"    # IP embosser Index Basic-D
$Port     = 9100               # port cetak embosser
$HttpPort = 8080               # port untuk fon (boleh tukar jika dipakai)
$Aplikasi = Join-Path $PSScriptRoot 'Aplikasi_Braille.html'
# ===================

$ErrorActionPreference = 'Stop'
$Log = Join-Path $PSScriptRoot 'log_pelayan.txt'
function Log($m) { $l = "{0:yyyy-MM-dd HH:mm:ss}  {1}" -f (Get-Date), $m; Write-Host $l; try { Add-Content -Path $Log -Value $l } catch {} }

function Send-Bytes([byte[]]$b) {
  $c = New-Object Net.Sockets.TcpClient
  try {
    $iar = $c.BeginConnect($IP, $Port, $null, $null)
    if (-not $iar.AsyncWaitHandle.WaitOne(5000)) { throw "Tak dapat sambung ke embosser ${IP}:${Port}. Semak embosser dihidupkan dan IP betul." }
    $c.EndConnect($iar)
    $s = $c.GetStream(); $s.Write($b, 0, $b.Length); $s.Flush(); $s.Close()
  } finally { $c.Close() }
}


# Cetak USB: hantar RAW terus ke pencetak Windows (pemacu Index)
$RawSrc = @'
using System;using System.Runtime.InteropServices;public class RawP{[StructLayout(LayoutKind.Sequential,CharSet=CharSet.Ansi)]public class DI{[MarshalAs(UnmanagedType.LPStr)]public string a;[MarshalAs(UnmanagedType.LPStr)]public string b;[MarshalAs(UnmanagedType.LPStr)]public string c;}[DllImport("winspool.Drv",EntryPoint="OpenPrinterA",SetLastError=true,CharSet=CharSet.Ansi,ExactSpelling=true)]public static extern bool OpenPrinter(string n,out IntPtr h,IntPtr d);[DllImport("winspool.Drv",SetLastError=true,ExactSpelling=true)]public static extern bool ClosePrinter(IntPtr h);[DllImport("winspool.Drv",EntryPoint="StartDocPrinterA",SetLastError=true,CharSet=CharSet.Ansi,ExactSpelling=true)]public static extern bool StartDocPrinter(IntPtr h,Int32 l,[In,MarshalAs(UnmanagedType.LPStruct)]DI d);[DllImport("winspool.Drv",SetLastError=true,ExactSpelling=true)]public static extern bool EndDocPrinter(IntPtr h);[DllImport("winspool.Drv",SetLastError=true,ExactSpelling=true)]public static extern bool StartPagePrinter(IntPtr h);[DllImport("winspool.Drv",SetLastError=true,ExactSpelling=true)]public static extern bool EndPagePrinter(IntPtr h);[DllImport("winspool.Drv",SetLastError=true,ExactSpelling=true)]public static extern bool WritePrinter(IntPtr h,IntPtr p,Int32 c,out Int32 w);public static string Send(string n,byte[] d){IntPtr h;if(!OpenPrinter(n,out h,IntPtr.Zero))return "Pencetak tidak dijumpai: "+n;DI di=new DI();di.a="Titik";di.b=null;di.c="RAW";if(!StartDocPrinter(h,1,di)){ClosePrinter(h);return "StartDoc gagal";}StartPagePrinter(h);IntPtr p=Marshal.AllocCoTaskMem(d.Length);Marshal.Copy(d,0,p,d.Length);int w;bool ok=WritePrinter(h,p,d.Length,out w);Marshal.FreeCoTaskMem(p);EndPagePrinter(h);EndDocPrinter(h);ClosePrinter(h);return ok?("Dihantar "+w+" bait"):"WritePrinter gagal";}}
'@
try { Add-Type -TypeDefinition $RawSrc } catch {}
function Send-Usb([string]$name, [byte[]]$b) {
  $r = [RawP]::Send($name, $b)
  if ($r -notlike 'Dihantar*') { throw $r }
}

# Benarkan aplikasi web (dibuka dalam Claude) memanggil pelayan ini dari PC yang sama
function Cors($req, $res) {
  $o = $req.Headers['Origin']
  if ($o -and ($o -match '^https://([a-z0-9-]+\.)*claude(usercontent)?\.(ai|com)$' -or $o -eq 'null' -or $o -match '^http://(localhost|127\.0\.0\.1|192\.168\.\d+\.\d+)(:\d+)?$')) {
    $res.Headers.Add('Access-Control-Allow-Origin', $o)
    $res.Headers.Add('Vary', 'Origin')
    $res.Headers.Add('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    $res.Headers.Add('Access-Control-Allow-Headers', 'Content-Type')
    $res.Headers.Add('Access-Control-Allow-Private-Network', 'true')
  }
}
function Reply($res, [int]$code, [string]$type, [byte[]]$body) {
  $res.StatusCode = $code
  $res.ContentType = $type
  $res.Headers.Add('Cache-Control', 'no-store')
  $res.ContentLength64 = $body.Length
  $res.OutputStream.Write($body, 0, $body.Length)
}
function Json($res, [int]$code, $obj) {
  Reply $res $code 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress)))
}

if (-not (Test-Path $Aplikasi)) { Write-Host "Fail Aplikasi_Braille.html tiada dalam folder ini." -ForegroundColor Red; exit 1 }

$L = New-Object Net.HttpListener
$L.Prefixes.Add("http://+:$HttpPort/")
try { $L.Start() } catch { Write-Host "Gagal mula pelayan: $($_.Exception.Message)`nPastikan dijalankan sebagai Administrator (Mula_Pelayan.bat akan minta kebenaran) dan port $HttpPort tidak dipakai." -ForegroundColor Red; exit 1 }

Write-Host ""
Write-Host "=== PELAYAN CETAK BRAILLE AKTIF ===" -ForegroundColor Green
Write-Host "Embosser: ${IP}:${Port}"
Write-Host "Buka di fon (Wi-Fi sekolah yang sama) salah satu alamat ini:"
Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
  Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
  ForEach-Object { Write-Host ("   http://{0}:{1}" -f $_.IPAddress, $HttpPort) -ForegroundColor Yellow }
Write-Host "Tutup tetingkap ini untuk berhenti."
Write-Host ""

while ($L.IsListening) {
  $ctx = $L.GetContext(); $req = $ctx.Request; $res = $ctx.Response
  try {
    $path = $req.Url.AbsolutePath
    Cors $req $res
    if ($req.HttpMethod -eq 'OPTIONS') { $res.StatusCode = 204; $res.ContentLength64 = 0 }
    elseif ($path -eq '/ping') {
      Json $res 200 @{ pantau = $true; ip = $IP; usb = $true }
    }
    elseif ($path -eq '/print' -and $req.HttpMethod -eq 'POST') {
      $ms = New-Object IO.MemoryStream
      $req.InputStream.CopyTo($ms)
      $b = $ms.ToArray()
      if ($b.Length -eq 0) { throw "Tiada data BRF diterima." }
      if ($b.Length -gt 20MB) { throw "Fail terlalu besar." }
      $pn = $req.QueryString['printer']
      if ($pn) {
        Log "Cetak USB '$pn' dari $($req.RemoteEndPoint.Address): $($b.Length) bait"
        Send-Usb $pn $b
      } else {
        Log "Cetak dari $($req.RemoteEndPoint.Address): $($b.Length) bait"
        Send-Bytes $b
      }
      Log "Siap dihantar ke embosser."
      Json $res 200 @{ ok = $true; bytes = $b.Length }
    }
    elseif ($path -eq '/' -or $path -eq '/index.html') {
      Reply $res 200 'text/html; charset=utf-8' ([IO.File]::ReadAllBytes($Aplikasi))
    }
    else {
      Json $res 404 @{ error = 'tiada' }
    }
  } catch {
    Log "RALAT: $($_.Exception.Message)"
    try { Json $res 500 @{ error = $_.Exception.Message } } catch {}
  } finally {
    try { $res.OutputStream.Close() } catch {}
  }
}
