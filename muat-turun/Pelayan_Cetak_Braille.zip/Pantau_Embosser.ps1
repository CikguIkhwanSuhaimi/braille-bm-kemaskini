# Pantau folder dan hantar fail BRF ke embosser Index Basic-D (port 9100).
# SMK Pendidikan Khas Setapak. Jalankan dengan Mula_Pantau.bat (klik dua kali).
#
# CARA GUNA: letakkan fail .brf, .brf.txt atau .zip (daripada aplikasi) ke dalam folder di bawah.
# Fail yang berjaya dipindahkan ke subfolder "Siap". Yang gagal ke subfolder "Gagal".

# ===== TETAPAN (ubah di sini sahaja) =====
$Folder = "$env:USERPROFILE\Embosser"     # folder yang dipantau. Boleh tukar ke folder Google Drive, contoh: "G:\My Drive\Embosser"
$IP     = "192.168.0.240"                 # IP embosser
$Port   = 9100
$Uji    = $false                          # tukar kepada $true untuk uji sambungan sahaja (tiada cetakan)
# =========================================

$ErrorActionPreference = 'Stop'
$Siap = Join-Path $Folder 'Siap'; $Gagal = Join-Path $Folder 'Gagal'; $Log = Join-Path $Folder 'log.txt'
New-Item -ItemType Directory -Force -Path $Folder, $Siap, $Gagal | Out-Null

function Log($m) {
  $l = "{0:yyyy-MM-dd HH:mm:ss}  {1}" -f (Get-Date), $m
  Write-Host $l
  try { Add-Content -Path $Log -Value $l } catch {}
}

function Send-Bytes([byte[]]$b) {
  $c = New-Object Net.Sockets.TcpClient
  try {
    $iar = $c.BeginConnect($IP, $Port, $null, $null)
    if (-not $iar.AsyncWaitHandle.WaitOne(5000)) { throw "Tak dapat sambung ke ${IP}:${Port} (tamat masa). Semak embosser dihidupkan dan IP betul." }
    $c.EndConnect($iar)
    $s = $c.GetStream()
    $s.Write($b, 0, $b.Length)
    $s.Flush()
    $s.Close()
  } finally { $c.Close() }
}

function Is-Ready($f) {
  # fail tidak sedang ditulis atau disegerak
  try {
    $fs = [IO.File]::Open($f.FullName, 'Open', 'Read', 'None'); $fs.Close()
    return ($f.LastWriteTime -lt (Get-Date).AddSeconds(-3))
  } catch { return $false }
}

if ($Uji) {
  try {
    $c = New-Object Net.Sockets.TcpClient
    $iar = $c.BeginConnect($IP, $Port, $null, $null)
    if ($iar.AsyncWaitHandle.WaitOne(5000)) { $c.EndConnect($iar); Log "Sambungan BERJAYA ke ${IP}:${Port}" } else { Log "Sambungan GAGAL ke ${IP}:${Port}" }
    $c.Close()
  } catch { Log "Sambungan GAGAL: $($_.Exception.Message)" }
  Read-Host "Tekan Enter untuk tutup"
  exit
}

Log "Memantau folder: $Folder  ->  embosser ${IP}:${Port}"
Log "Letakkan fail .brf, .brf.txt atau .zip dalam folder itu. Tutup tetingkap ini untuk berhenti."

while ($true) {
  $files = Get-ChildItem -Path $Folder -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '\.(brf|brf\.txt|zip)$' }
  foreach ($f in $files) {
    if (-not (Is-Ready $f)) { continue }
    try {
      if ($f.Extension -eq '.zip') {
        $tmp = Join-Path $env:TEMP ("brf_" + [guid]::NewGuid().ToString('N'))
        Expand-Archive -LiteralPath $f.FullName -DestinationPath $tmp -Force
        $brfs = @(Get-ChildItem -Path $tmp -Recurse -File | Where-Object { $_.Name -match '\.brf(\.txt)?$' })
        if ($brfs.Count -eq 0) { throw "Tiada fail .brf dalam zip" }
        foreach ($x in $brfs) {
          Log "Menghantar $($f.Name) / $($x.Name) ($([int]$x.Length) bait)"
          Send-Bytes ([IO.File]::ReadAllBytes($x.FullName))
        }
        Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
      } else {
        Log "Menghantar $($f.Name) ($([int]$f.Length) bait)"
        Send-Bytes ([IO.File]::ReadAllBytes($f.FullName))
      }
      Move-Item -LiteralPath $f.FullName -Destination (Join-Path $Siap ("{0:yyyyMMdd_HHmmss}_{1}" -f (Get-Date), $f.Name)) -Force
      Log "Siap: $($f.Name) dihantar ke embosser."
    } catch {
      Log "GAGAL: $($f.Name) - $($_.Exception.Message)"
      try { Move-Item -LiteralPath $f.FullName -Destination (Join-Path $Gagal ("{0:yyyyMMdd_HHmmss}_{1}" -f (Get-Date), $f.Name)) -Force } catch {}
      Log "Fail dipindahkan ke folder Gagal. Pindahkan semula ke folder utama untuk cuba lagi."
    }
  }
  Start-Sleep -Seconds 3
}
