@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs -WindowStyle Hidden"
  exit /b
)
netsh advfirewall firewall show rule name="Pelayan Cetak Braille" >nul 2>&1 || netsh advfirewall firewall add rule name="Pelayan Cetak Braille" dir=in action=allow protocol=TCP localport=8080 profile=any >nul
powershell -NoProfile -WindowStyle Hidden -Command "Start-Process powershell -WindowStyle Hidden -ArgumentList '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%~dp0Pelayan_Cetak.ps1\"'"
