@echo off
title Pasang pelayan cetak automatik
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
echo Memasang sekali sahaja...
netsh advfirewall firewall show rule name="Pelayan Cetak Braille" >nul 2>&1 || netsh advfirewall firewall add rule name="Pelayan Cetak Braille" dir=in action=allow protocol=TCP localport=8080 profile=any >nul
netsh http delete urlacl url=http://+:8080/ >nul 2>&1
netsh http add urlacl url=http://+:8080/ sddl="D:(A;;GX;;;WD)" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('CommonStartup')+'\Pelayan Cetak Braille.lnk');$s.TargetPath='wscript.exe';$s.Arguments='//B //Nologo \"%~dp0Senyap.vbs\"';$s.WorkingDirectory='%~dp0';$s.Save()"
reg add "HKCR\bprint" /ve /d "URL:Pelayan Cetak Braille" /f >nul
reg add "HKCR\bprint" /v "URL Protocol" /d "" /f >nul
reg add "HKCR\bprint\shell\open\command" /ve /d "wscript.exe //B //Nologo \"%~dp0Senyap.vbs\"" /f >nul
echo.
echo Siap. Pelayan cetak akan jalan sendiri setiap kali PC dihidupkan,
echo dan butang Cetak terus dalam aplikasi boleh memulakannya jika belum jalan.
echo Jangan alih folder ini. Jika dialih, jalankan fail ini sekali lagi.
echo Untuk mula sekarang tanpa restart: klik dua kali Mula_Pelayan.bat atau restart PC.
pause
